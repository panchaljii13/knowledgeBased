import React from "react";
import Header from "../Header/Header.js"
import Content from "../Content/Contents.js"


const Home = () => {

   

    return (
    <>
        <Header/>
        <Content />
    </>
    );
};

export default Home;
